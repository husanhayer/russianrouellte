﻿


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace russianroulette
{
    public partial class Form2 : Form
    {
        public int counter = 0; 
        // below code is to declare the variables those are used in this form
        
        public Form2()
        {
            InitializeComponent();
        }
        // below code is used to get the values of name and age from form1
        private void Form2_Load(object sender, EventArgs e)
        {
            textBox1.Text = Form1.A;
            textBox2.Text = Convert.ToString(Form1.age);

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

            (new Form2()).Show();
            this.Close();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            //Below code is for uploading image
            Image img = Image.FromFile(@"C:\Users\HUSAN HAYER\Source\Repos\russianroulette\Resources\j3.gif");
            pictureBox1.Image = img;
            
            //calling fire_sound function from Sound class
            Sound fire = new Sound();
            fire.Fire_Sound();

            int s = 0;

            Game FireObj = new Game();
            int score1 = FireObj.Fire_bullet(s);

            if (score1 == 10)
            {
                //code to print the message box
                MessageBox.Show("Wow! you won. You score is " + score1);
            }

            else if (score1 == 5)
            {
               //code to print the message box
                MessageBox.Show("Wow! you won. You score is " + score1);
            }
            else
            {
                counter++;
            }

            if (counter == 2)
            {
                //code to print the message box
                MessageBox.Show("sorry you loss. Best of luck for next time  ");
            }


            }

            private void button1_Click(object sender, EventArgs e)
        {
            //Below code is for uploading image
            Image img = Image.FromFile(@"C:\Users\HUSAN HAYER\Source\Repos\russianroulette\Resources\j9.gif");
            pictureBox1.Image = img;

            Game LoadObj = new Game();
            LoadObj.load_value();
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Below code is for uploading image
            Image img = Image.FromFile(@"C:\Users\HUSAN HAYER\Source\Repos\russianroulette\Resources\GIF.gif");
            pictureBox1.Image = img;

            //Spinobj object is used to call the spin_sound function from Sound class. 
            Sound Spinobj = new Sound();
            Spinobj.Spin_Sound();

            //below code is to call the spin chamber function from Game class
            Game SpinObj = new Game();
            SpinObj.Spin_Chamber();
        }

        private void button5_Click(object sender, EventArgs e)
        {

        }
    }
}