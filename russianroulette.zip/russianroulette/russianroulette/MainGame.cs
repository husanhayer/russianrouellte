﻿


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace russianroulette
{
    public partial class MainGame : Form
    {
        public int counter = 0; 
        // below code is to declare the variables those are used in this form
        
        public MainGame()
        {
            InitializeComponent();
        }
        // below code is used to get the values of name and age from form1
       
     

        


        private void MainGame_Load(object sender, EventArgs e)
        {
            Name_TxtBox.Text = LoginForm.Name_var;
            Age_TextBox.Text = Convert.ToString(LoginForm.age);

        }

        

        private void ShootAway_Button_Click(object sender, EventArgs e)
        {
            (new MainGame()).Show();
            this.Close();
            Name_TxtBox.Text = LoginForm.Name_var;
            Age_TextBox.Text = Convert.ToString(LoginForm.age);

        }

        private void fire_btn_Click(object sender, EventArgs e)
        {
            //Below code is for uploading image
            Image img = Image.FromFile(@"C:\Users\HUSAN HAYER\Source\Repos\russianroulette\Resources\j3.gif");
            pictureBox1.Image = img;

            //calling fire_sound function from Sound class
            Sound fire = new Sound();
            fire.Fire_Sound();

            int s = 0;

            Game FireObj = new Game();
            int score1 = FireObj.Fire_bullet(s);

            if (score1 == 10)
            {
                //code to print the message box
                MessageBox.Show("Wow! you won. You score is " + score1);
            }

            else if (score1 == 5)
            {
                //code to print the message box
                MessageBox.Show("Wow! you won. You score is " + score1);
            }
            else
            {
                counter++;
            }

            if (counter == 2)
            {
                //code to print the message box
                MessageBox.Show("sorry you loss. Best of luck for next time  ");
            }

        }

        private void loadbtn_Click(object sender, EventArgs e)
        {
            //Below code is for uploading image
            Image img = Image.FromFile(@"C:\Users\HUSAN HAYER\Source\Repos\russianroulette\Resources\j9.gif");
            pictureBox1.Image = img;

            Game LoadObj = new Game();
            LoadObj.load_value();

        }

        private void spin_btn_Click(object sender, EventArgs e)
        {
            //Below code is for uploading image
            Image img = Image.FromFile(@"C:\Users\HUSAN HAYER\Source\Repos\russianroulette\Resources\GIF.gif");
            pictureBox1.Image = img;

            //Spinobj object is used to call the spin_sound function from Sound class. 
            Sound Spinobj = new Sound();
            Spinobj.Spin_Sound();

            //below code is to call the spin chamber function from Game class
            Game SpinObj = new Game();
            SpinObj.Spin_Chamber();
        }

        private void Exit_Btn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
    }
