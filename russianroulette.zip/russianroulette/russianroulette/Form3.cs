﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace russianroulette
{
    public partial class WelcomePage : Form
    {
        public WelcomePage()
        {
            InitializeComponent();
        }



        private void Next_Btn_Click(object sender, EventArgs e)
        {
            // below code is used to hide the form3 and show form1

            (new LoginForm()).Show();
            this.Hide();

        }
    }
}
