﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace russianroulette
{
    public partial class LoginForm : Form
    {
        // below code is to declare public variables
        public static string Name_var;
        public static int age;
        public LoginForm()
        {   
            InitializeComponent();
        }
     
        private void LoginPage_Load(object sender, EventArgs e)
        {
        }
        private void Play_Button_Click(object sender, EventArgs e)
        {

            // bleow code is for enter the value of age
            if (!int.TryParse(Age_TxtBox.Text, out age))
            {
                Age_TxtBox.Text = "please enter AGE in numbers";
            }
            else
            {
                age = Convert.ToInt16(Age_TxtBox.Text);
            }

            if (Name_TxtBox.Text == "")
            {
                Name_TxtBox.Text = "please enter the name first";
            }
            else if (age == 0)
            {
                Age_TxtBox.Text = "please enter AGE";
            }
            else
            {
                //bleow code is for print the age
                age = Convert.ToInt16(Age_TxtBox.Text);
                Name_var = Name_TxtBox.Text;
                // below code is used to show form2 and hide form1
                (new MainGame()).Show();
                this.Hide();
            }
        }
    }
}

