﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace russianroulette
{
    public class Game
    {
        public static int load = 0, spin = 0, score = 0, counter = 0;

        public void load_value()
            {
                load = 1;
            }

        public void Spin_Chamber()
        {
            // code below is to pic the random number from 1 to 6
            Random random = new Random();
            spin = random.Next(1, 7);
        
        }

        public int Fire_bullet(int sc)
        {
            if (counter < 2)
            {
               if (spin == load)
                {
                    score = scoreval(counter);
                    counter = 2;
                }
                else if (spin == 6)
                {
                    spin = 1;
                    counter++;
                }
                else
                {
                    spin++;
                    counter++;
                }
            }
            return score;
        }

        public int scoreval(int count)
        {
            if (counter == 0)
            {
                score = score + 10;
            }
            else if (counter == 1)
            {
                score = score + 5;
            }
            
            return score;
        }
        
        
    }
}
