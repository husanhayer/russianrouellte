﻿namespace russianroulette
{
    partial class MainGame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainGame));
            this.loadbtn = new System.Windows.Forms.Button();
            this.spinbtn = new System.Windows.Forms.Button();
            this.ShootAway_Button = new System.Windows.Forms.Button();
            this.Name_TxtBox = new System.Windows.Forms.TextBox();
            this.Age_TextBox = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.fire_button = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.Exit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // loadbtn
            // 
            this.loadbtn.BackColor = System.Drawing.Color.Khaki;
            this.loadbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loadbtn.Location = new System.Drawing.Point(99, 196);
            this.loadbtn.Name = "loadbtn";
            this.loadbtn.Size = new System.Drawing.Size(92, 62);
            this.loadbtn.TabIndex = 0;
            this.loadbtn.Text = "load";
            this.loadbtn.UseVisualStyleBackColor = false;
            this.loadbtn.Click += new System.EventHandler(this.loadbtn_Click);
            // 
            // spinbtn
            // 
            this.spinbtn.BackColor = System.Drawing.Color.Khaki;
            this.spinbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.spinbtn.Location = new System.Drawing.Point(208, 196);
            this.spinbtn.Name = "spinbtn";
            this.spinbtn.Size = new System.Drawing.Size(92, 62);
            this.spinbtn.TabIndex = 1;
            this.spinbtn.Text = "spin";
            this.spinbtn.UseVisualStyleBackColor = false;
            this.spinbtn.Click += new System.EventHandler(this.spin_btn_Click);
            // 
            // ShootAway_Button
            // 
            this.ShootAway_Button.BackColor = System.Drawing.Color.White;
            this.ShootAway_Button.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ShootAway_Button.Location = new System.Drawing.Point(137, 368);
            this.ShootAway_Button.Name = "ShootAway_Button";
            this.ShootAway_Button.Size = new System.Drawing.Size(131, 61);
            this.ShootAway_Button.TabIndex = 3;
            this.ShootAway_Button.Text = "Shoot Away";
            this.ShootAway_Button.UseVisualStyleBackColor = false;
            this.ShootAway_Button.Click += new System.EventHandler(this.ShootAway_Button_Click);
            // 
            // textBox1
            // 
            this.Name_TxtBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.Name_TxtBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name_TxtBox.Location = new System.Drawing.Point(197, 11);
            this.Name_TxtBox.Name = "textBox1";
            this.Name_TxtBox.Size = new System.Drawing.Size(120, 26);
            this.Name_TxtBox.TabIndex = 4;
            // 
            // textBox2
            // 
            this.Age_TextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.Age_TextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Age_TextBox.Location = new System.Drawing.Point(197, 46);
            this.Age_TextBox.Name = "textBox2";
            this.Age_TextBox.Size = new System.Drawing.Size(120, 26);
            this.Age_TextBox.TabIndex = 5;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.Location = new System.Drawing.Point(539, 196);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(184, 144);
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(24, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(165, 20);
            this.label1.TabIndex = 7;
            this.label1.Text = "PLAYER\'S NAME =";
            // 
            // fire_button
            // 
            this.fire_button.BackColor = System.Drawing.Color.Red;
            this.fire_button.ForeColor = System.Drawing.Color.Black;
            this.fire_button.Location = new System.Drawing.Point(152, 289);
            this.fire_button.Name = "fire_button";
            this.fire_button.Size = new System.Drawing.Size(90, 41);
            this.fire_button.TabIndex = 9;
            this.fire_button.Text = "FIRE";
            this.fire_button.UseVisualStyleBackColor = false;
            this.fire_button.Click += new System.EventHandler(this.fire_btn_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(25, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(153, 20);
            this.label2.TabIndex = 10;
            this.label2.Text = "PLAYER\'S AGE =";
            // 
            // Exit
            // 
            this.Exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Exit.Location = new System.Drawing.Point(678, 406);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(88, 32);
            this.Exit.TabIndex = 11;
            this.Exit.Text = "Exit";
            this.Exit.UseVisualStyleBackColor = true;
            this.Exit.Click += new System.EventHandler(this.Exit_Btn_Click);
            // 
            // MainGame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.fire_button);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Age_TextBox);
            this.Controls.Add(this.Name_TxtBox);
            this.Controls.Add(this.ShootAway_Button);
            this.Controls.Add(this.spinbtn);
            this.Controls.Add(this.loadbtn);
            this.Name = "MainGame";
            this.Text = "Main Game";
            this.Load += new System.EventHandler(this.MainGame_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button loadbtn;
        private System.Windows.Forms.Button spinbtn;
        private System.Windows.Forms.Button ShootAway_Button;
        private System.Windows.Forms.TextBox Name_TxtBox;
        private System.Windows.Forms.TextBox Age_TextBox;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button fire_button;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Exit;
    }
}