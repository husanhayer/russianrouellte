﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace russianroulette
{
    public class Sound
    {
        public void Spin_Sound()
        {
            //below code is for uploading sound
            System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"C:\Users\HUSAN HAYER\Source\Repos\russianroulette\Resources\spin.wav");
            player.Play();

        }

        public void Fire_Sound()
        {
            // below code is for uploading sound
            System.Media.SoundPlayer player1 = new System.Media.SoundPlayer(@"C:\Users\HUSAN HAYER\Source\Repos\russianroulette\Resources\fire.wav");
               player1.Play();
        }

    }
}
