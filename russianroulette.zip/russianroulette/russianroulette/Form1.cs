﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace russianroulette
{
    public partial class Form1 : Form
    {
        // below code is to declare public variables
        public static string A;
        public static int age;
        public Form1()
        {   
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {   }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }


        private void button4_Click(object sender, EventArgs e)
        {

        }


        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
           // bleow code is for enter the value of age
            if (!int.TryParse(textBox1.Text, out age))
            {
                textBox1.Text = "please enter AGE in numbers";
            }
            else
            {
                age = Convert.ToInt16(textBox1.Text);
            }

            if (textBox4.Text == "")
            {
                textBox4.Text = "please enter the name first";
            }
            else if (age == 0)
            {
                textBox1.Text = "please enter AGE";
            }
            else
            {
                //bleow code is for print the age
                age = Convert.ToInt16(textBox1.Text);
                A = textBox4.Text;
                // below code is used to show form2 and hide form1
                (new Form2()).Show();
                this.Hide();
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {
        }
    }
}

