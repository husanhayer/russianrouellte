﻿namespace russianroulette
{
    partial class LoginForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LoginForm));
            this.Play_button = new System.Windows.Forms.Button();
            this.Name_TxtBox = new System.Windows.Forms.TextBox();
            this.Age_TxtBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // Play_button
            // 
            this.Play_button.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.Play_button.Location = new System.Drawing.Point(620, 390);
            this.Play_button.Name = "Play_button";
            this.Play_button.Size = new System.Drawing.Size(135, 54);
            this.Play_button.TabIndex = 8;
            this.Play_button.Text = "PLAY";
            this.Play_button.UseVisualStyleBackColor = false;
            this.Play_button.Click += new System.EventHandler(this.Play_Button_Click);
            // 
            // Name_TxtBox
            // 
            this.Name_TxtBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Name_TxtBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name_TxtBox.Location = new System.Drawing.Point(415, 199);
            this.Name_TxtBox.Name = "Name_TxtBox";
            this.Name_TxtBox.Size = new System.Drawing.Size(250, 26);
            this.Name_TxtBox.TabIndex = 9;
            // 
            // Age_TxtBox
            // 
            this.Age_TxtBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Age_TxtBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Age_TxtBox.Location = new System.Drawing.Point(346, 246);
            this.Age_TxtBox.Name = "Age_TxtBox";
            this.Age_TxtBox.Size = new System.Drawing.Size(288, 26);
            this.Age_TxtBox.TabIndex = 10;
            // 
            // LoginForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(20F, 37F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(814, 482);
            this.Controls.Add(this.Age_TxtBox);
            this.Controls.Add(this.Name_TxtBox);
            this.Controls.Add(this.Play_button);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.MaximumSize = new System.Drawing.Size(830, 521);
            this.Name = "LoginForm";
            this.Text = "Login Page";
            this.Load += new System.EventHandler(this.LoginPage_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button Play_button;
        private System.Windows.Forms.TextBox Name_TxtBox;
        private System.Windows.Forms.TextBox Age_TxtBox;
    }
}

