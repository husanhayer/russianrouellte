﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace russianroulette
{
    [TestFixture]
    class Testing
    {
        [TestCase]
        public void Score()
        {
            Game scoreobj = new Game();
            Assert.AreEqual(10, scoreobj.scoreval(0));
        }
    }
}
